

# flutter_pose_estimation

## Install 

```
flutter packages get
```

## Run

```
flutter run
```

## Models

- Pose Estimation 
  - PoseNet



"# Flutter-Pose-Estimation-" 
