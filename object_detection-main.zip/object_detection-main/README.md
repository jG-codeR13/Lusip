# object_detection
## Machine Learning powered Android Application
This application can detect objects in any of the three ways:
  * Image choosen from Gallery
  * From image taken within the App
  * Real time in video stream
